import numpy as np
from numpy import asarray
import cv2
import matplotlib.pyplot as plt
import os
from keras.utils import to_categorical
from keras.models import Sequential
from keras.layers import Conv2D,MaxPooling2D,Dense,Flatten


COVID=os.listdir('Train_images/COVID')
Non_COVID=os.listdir('Train_images/Non-COVID')
data=np.concatenate([COVID,Non_COVID])
target_x=np.full(len(COVID),1)
target_y=np.full(len(Non_COVID),0)
data_target=np.concatenate([target_x,target_y])
yes_values=os.listdir('Train_images/COVID')
no_values=os.listdir('Train_images/Non-COVID')
X_data =[]
for file in yes_values:
    img = cv2.imread('Train_images/COVID/'+file,cv2.IMREAD_GRAYSCALE)
    img= cv2.resize(img, (250,250))
    X_data.append(img)
#X_data =[]
for file in no_values:
    img = cv2.imread('Train_images/Non-COVID/'+file,cv2.IMREAD_GRAYSCALE)
    img=cv2.resize(img,(250,250))
    X_data.append(img)
X_train=np.array(X_data[:500])
X_test=np.array(X_data[500:])
y_train=data_target[:500]


y_test=data_target[500:]

X_train=X_train.reshape(X_train.shape[0],250,250,1)
X_test=X_test.reshape(X_test.shape[0],250,250,1)

X_train=X_train.astype('float32')
X_test=X_test.astype('float32')

X_train/=255-0.5
X_test/=255-0.5

num_filters=10
filter_size=3
pool_size1=2

model=Sequential()
model.add(Conv2D(num_filters,filter_size,strides=(1,1),input_shape=(250,250,1)))
model.add(MaxPooling2D(pool_size=pool_size1))
model.add(Flatten())
model.add(Dense(1,activation='sigmoid'))
model.compile('adam',loss='binary_crossentropy',metrics=['accuracy'])
model.summary()

model.fit(X_train,y_train,epochs=6,verbose=1,validation_data=(X_test,y_test),)
score=model.evaluate(X_test,y_test,verbose=0)
